/*
 * quran-sheet.js - tampilkan app Quran sebagai lembar (bottom sheet) di dalam app lain.
 *
 * Pasang di app lain:
 *   <script src="quran-sheet.js" data-url="https://ALAMAT-APP-QURAN-ANDA/index.html"></script>
 *   <button onclick="QuranSheet.open()">Baca Al-Qur'an</button>
 *
 * API: QuranSheet.open([url]) | QuranSheet.close() | QuranSheet.isOpen()
 */
(function () {
  var script = document.currentScript;
  var URL_QURAN = (script && script.dataset.url) || 'index.html';
  var TITLE = (script && script.dataset.title) || "Baca Al-Qur\u2019an";
  var CLOSE = (script && script.dataset.close) || 'Tutup';

  var css = '\
#qs-scrim{position:fixed;inset:0;z-index:99998;background:rgba(0,0,0,.55);opacity:0;visibility:hidden;transition:opacity .25s,visibility .25s}\
#qs-scrim.on{opacity:1;visibility:visible}\
#qs-sheet{position:fixed;left:0;right:0;bottom:0;top:max(64px,env(safe-area-inset-top,0px));z-index:99999;display:flex;flex-direction:column;\
background:#0B1015;border-radius:22px 22px 0 0;overflow:hidden;box-shadow:0 -6px 28px rgba(0,0,0,.5);\
transform:translateY(100%);visibility:hidden;transition:transform .3s cubic-bezier(.2,.8,.2,1),visibility .3s}\
#qs-sheet.on{transform:none;visibility:visible}\
#qs-head{flex:none;display:flex;align-items:center;justify-content:space-between;padding:14px 16px 12px 20px;background:#0B1015}\
#qs-head b{font:400 24px/1.2 Georgia,"Times New Roman",serif;color:#F3EFE0}\
#qs-close{border:0;cursor:pointer;padding:10px 22px;border-radius:999px;background:#1B222B;color:#F3EFE0;font:700 17px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}\
#qs-close:active{background:#2A333F}\
#qs-frame{flex:1;width:100%;border:0;background:#0A1512;padding-bottom:env(safe-area-inset-bottom,0px)}\
body.qs-lock{overflow:hidden}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  var scrim = document.createElement('div'); scrim.id = 'qs-scrim';
  var sheet = document.createElement('div'); sheet.id = 'qs-sheet';
  sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-modal', 'true'); sheet.setAttribute('aria-label', TITLE);
  sheet.innerHTML = '<div id="qs-head"><b></b><button id="qs-close" type="button"></button></div>';
  sheet.querySelector('b').textContent = TITLE;
  sheet.querySelector('#qs-close').textContent = CLOSE;
  var frame = null, opened = false, pushed = false;

  function attach() { document.body.appendChild(scrim); document.body.appendChild(sheet); }
  if (document.body) attach(); else document.addEventListener('DOMContentLoaded', attach);

  function open(url) {
    if (opened) return;
    if (!frame) { // dibuat sekali, dipertahankan agar halaman terakhir tidak hilang
      frame = document.createElement('iframe'); frame.id = 'qs-frame';
      frame.title = TITLE; frame.allow = 'fullscreen; autoplay';
      frame.src = url || URL_QURAN; sheet.appendChild(frame);
    } else if (url && frame.getAttribute('src') !== url) frame.src = url;
    opened = true;
    document.body.classList.add('qs-lock');
    scrim.classList.add('on'); sheet.classList.add('on');
    history.pushState({ qs: 1 }, ''); pushed = true; // tombol Back HP menutup lembar
  }
  function close(fromPop) {
    if (!opened) return;
    opened = false;
    scrim.classList.remove('on'); sheet.classList.remove('on');
    document.body.classList.remove('qs-lock');
    if (!fromPop && pushed) history.back();
    pushed = false;
  }
  sheet.querySelector('#qs-close').addEventListener('click', function () { close(false); });
  scrim.addEventListener('click', function () { close(false); });
  window.addEventListener('popstate', function () { if (opened) close(true); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(false); });

  window.QuranSheet = { open: open, close: function () { close(false); }, isOpen: function () { return opened; } };
})();
